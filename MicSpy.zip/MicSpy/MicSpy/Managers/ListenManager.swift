import Foundation
import Speech
import AVFoundation

@MainActor
class ListenManager: ObservableObject {
    @Published var isListening = false
    @Published var hasPermission = false
    @Published var permissionStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    @Published var sessions: [ListeningSession] = []
    @Published var currentTranscript = ""
    @Published var currentWordCount = 0
    @Published var listeningDuration: TimeInterval = 0
    
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var audioEngine = AVAudioEngine()
    
    private var sessionStartTime: Date?
    private var currentItems: [DetectedItem] = []
    private var timer: Timer?
    
    // Known keywords to detect
    private let brands = Set(["amazon", "google", "apple", "facebook", "meta", "netflix", "spotify", "uber", "walmart", "target", "starbucks", "mcdonald", "nike", "adidas", "samsung", "microsoft", "tesla", "instagram", "tiktok", "youtube", "twitter", "snapchat", "venmo", "paypal", "chase", "wells fargo", "bank of america", "costco", "whole foods", "trader joe", "doordash", "grubhub", "airbnb", "delta", "united", "southwest", "american airlines", "coca cola", "pepsi", "budweiser", "disney", "hulu", "hbo", "paramount"])
    
    private let products = Set(["iphone", "ipad", "macbook", "airpods", "laptop", "computer", "phone", "tablet", "headphones", "speaker", "camera", "watch", "tv", "television", "car", "truck", "shoes", "clothes", "furniture", "groceries", "food", "drinks", "coffee", "beer", "wine"])
    
    private let entertainment = Set(["movie", "show", "series", "episode", "season", "game", "music", "song", "album", "concert", "podcast", "news", "sports", "football", "basketball", "baseball", "soccer", "netflix", "hulu", "disney", "hbo", "prime video"])
    
    private let places = Set(["home", "work", "office", "store", "restaurant", "gym", "park", "beach", "airport", "hotel", "hospital", "school", "church", "downtown", "mall", "theater", "bar", "club"])
    
    init() {
        loadSessions()
    }
    
    func requestPermission() {
        SFSpeechRecognizer.requestAuthorization { [weak self] status in
            DispatchQueue.main.async {
                self?.permissionStatus = status
                self?.hasPermission = status == .authorized
            }
        }
        
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                if !granted {
                    self?.hasPermission = false
                }
            }
        }
    }
    
    func startListening() {
        guard hasPermission, !isListening else { return }
        
        sessionStartTime = Date()
        currentItems = []
        currentTranscript = ""
        currentWordCount = 0
        listeningDuration = 0
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { return }
            
            recognitionRequest.shouldReportPartialResults = true
            recognitionRequest.requiresOnDeviceRecognition = true // Privacy: on-device only!
            
            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                self.recognitionRequest?.append(buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
            
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                
                if let result = result {
                    let text = result.bestTranscription.formattedString
                    DispatchQueue.main.async {
                        self.currentTranscript = text
                        self.currentWordCount = text.split(separator: " ").count
                        self.processTranscript(text)
                    }
                }
                
                if error != nil || result?.isFinal == true {
                    // Recognition ended
                }
            }
            
            isListening = true
            
            // Timer to track duration
            timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
                guard let self = self, let start = self.sessionStartTime else { return }
                DispatchQueue.main.async {
                    self.listeningDuration = Date().timeIntervalSince(start)
                }
            }
            
        } catch {
            print("Failed to start listening: \(error)")
        }
    }
    
    func stopListening() {
        guard isListening else { return }
        
        timer?.invalidate()
        timer = nil
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil
        
        // Save session
        if let startTime = sessionStartTime {
            let session = ListeningSession(
                startTime: startTime,
                endTime: Date(),
                detectedItems: currentItems,
                wordCount: currentWordCount
            )
            sessions.insert(session, at: 0)
            saveSessions()
        }
        
        isListening = false
        sessionStartTime = nil
    }
    
    private func processTranscript(_ text: String) {
        let words = text.lowercased().split(separator: " ").map { String($0) }
        var newItems: [DetectedItem] = []
        
        for word in words {
            let cleanWord = word.trimmingCharacters(in: .punctuationCharacters)
            
            if brands.contains(cleanWord) {
                if !currentItems.contains(where: { $0.text.lowercased() == cleanWord && $0.category == .brand }) {
                    newItems.append(DetectedItem(text: cleanWord.capitalized, category: .brand))
                }
            } else if products.contains(cleanWord) {
                if !currentItems.contains(where: { $0.text.lowercased() == cleanWord && $0.category == .product }) {
                    newItems.append(DetectedItem(text: cleanWord.capitalized, category: .product))
                }
            } else if entertainment.contains(cleanWord) {
                if !currentItems.contains(where: { $0.text.lowercased() == cleanWord && $0.category == .entertainment }) {
                    newItems.append(DetectedItem(text: cleanWord.capitalized, category: .entertainment))
                }
            } else if places.contains(cleanWord) {
                if !currentItems.contains(where: { $0.text.lowercased() == cleanWord && $0.category == .place }) {
                    newItems.append(DetectedItem(text: cleanWord.capitalized, category: .place))
                }
            }
        }
        
        currentItems.append(contentsOf: newItems)
    }
    
    func getTodayReport() -> DailyReport {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let todaySessions = sessions.filter { calendar.startOfDay(for: $0.startTime) == today }
        return DailyReport(date: today, sessions: todaySessions)
    }
    
    func getAllTimeReport() -> DailyReport {
        return DailyReport(date: Date(), sessions: sessions)
    }
    
    func clearAllData() {
        sessions = []
        saveSessions()
    }
    
    private func saveSessions() {
        if let data = try? JSONEncoder().encode(sessions) {
            UserDefaults.standard.set(data, forKey: "listening_sessions")
        }
    }
    
    private func loadSessions() {
        if let data = UserDefaults.standard.data(forKey: "listening_sessions"),
           let decoded = try? JSONDecoder().decode([ListeningSession].self, from: data) {
            sessions = decoded
        }
    }
    
    func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
