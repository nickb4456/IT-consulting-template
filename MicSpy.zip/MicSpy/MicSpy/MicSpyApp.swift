import SwiftUI

@main
struct MicSpyApp: App {
    @StateObject private var listenManager = ListenManager()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(listenManager)
                .preferredColorScheme(.dark)
        }
    }
}
