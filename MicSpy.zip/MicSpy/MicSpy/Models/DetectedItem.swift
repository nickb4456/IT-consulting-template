import Foundation

struct DetectedItem: Identifiable, Codable {
    let id: UUID
    let text: String
    let category: ItemCategory
    let timestamp: Date
    
    init(text: String, category: ItemCategory) {
        self.id = UUID()
        self.text = text
        self.category = category
        self.timestamp = Date()
    }
}

enum ItemCategory: String, Codable, CaseIterable {
    case brand = "Brands"
    case person = "People"
    case place = "Places"
    case topic = "Topics"
    case entertainment = "Entertainment"
    case product = "Products"
    case unknown = "Other"
    
    var icon: String {
        switch self {
        case .brand: return "bag.fill"
        case .person: return "person.fill"
        case .place: return "mappin.circle.fill"
        case .topic: return "text.bubble.fill"
        case .entertainment: return "tv.fill"
        case .product: return "cart.fill"
        case .unknown: return "questionmark.circle.fill"
        }
    }
    
    var color: String {
        switch self {
        case .brand: return "orange"
        case .person: return "blue"
        case .place: return "green"
        case .topic: return "purple"
        case .entertainment: return "pink"
        case .product: return "yellow"
        case .unknown: return "gray"
        }
    }
}

struct ListeningSession: Identifiable, Codable {
    let id: UUID
    let startTime: Date
    let endTime: Date
    let detectedItems: [DetectedItem]
    let wordCount: Int
    
    init(startTime: Date, endTime: Date, detectedItems: [DetectedItem], wordCount: Int) {
        self.id = UUID()
        self.startTime = startTime
        self.endTime = endTime
        self.detectedItems = detectedItems
        self.wordCount = wordCount
    }
    
    var duration: TimeInterval {
        endTime.timeIntervalSince(startTime)
    }
}

struct DailyReport: Identifiable {
    let id = UUID()
    let date: Date
    let sessions: [ListeningSession]
    
    var totalDuration: TimeInterval {
        sessions.reduce(0) { $0 + $1.duration }
    }
    
    var totalWords: Int {
        sessions.reduce(0) { $0 + $1.wordCount }
    }
    
    var allItems: [DetectedItem] {
        sessions.flatMap { $0.detectedItems }
    }
    
    var itemsByCategory: [ItemCategory: [DetectedItem]] {
        Dictionary(grouping: allItems, by: { $0.category })
    }
    
    var uniqueTopics: Int {
        Set(allItems.map { $0.text.lowercased() }).count
    }
}
