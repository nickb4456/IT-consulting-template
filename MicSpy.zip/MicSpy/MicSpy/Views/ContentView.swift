import SwiftUI

struct ContentView: View {
    @EnvironmentObject var listenManager: ListenManager
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Label("Listen", systemImage: "mic.fill")
                }
                .tag(0)
            
            ReportView()
                .tabItem {
                    Label("Report", systemImage: "doc.text.fill")
                }
                .tag(1)
            
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
                .tag(2)
        }
        .tint(.red)
    }
}

#Preview {
    ContentView()
        .environmentObject(ListenManager())
}
