import SwiftUI

struct HomeView: View {
    @EnvironmentObject var listenManager: ListenManager
    @State private var showingAlert = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                VStack(spacing: 30) {
                    // Header
                    VStack(spacing: 8) {
                        Text("🎤 MicSpy")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        Text("See what apps could learn about you")
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 20)
                    
                    Spacer()
                    
                    if !listenManager.hasPermission {
                        // Permission needed
                        VStack(spacing: 20) {
                            Image(systemName: "mic.slash.fill")
                                .font(.system(size: 60))
                                .foregroundStyle(.red.opacity(0.7))
                            
                            Text("Microphone Access Required")
                                .font(.title2)
                                .fontWeight(.semibold)
                            
                            Text("To demonstrate what other apps could hear, we need microphone access.")
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal, 40)
                            
                            Button {
                                listenManager.requestPermission()
                            } label: {
                                Text("Grant Access")
                                    .fontWeight(.semibold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(.red)
                                    .foregroundStyle(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                            }
                            .padding(.horizontal, 40)
                        }
                    } else if listenManager.isListening {
                        // Currently listening
                        VStack(spacing: 25) {
                            // Pulsing mic animation
                            ZStack {
                                Circle()
                                    .fill(.red.opacity(0.2))
                                    .frame(width: 180, height: 180)
                                    .scaleEffect(listenManager.isListening ? 1.2 : 1.0)
                                    .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: listenManager.isListening)
                                
                                Circle()
                                    .fill(.red.opacity(0.3))
                                    .frame(width: 140, height: 140)
                                
                                Image(systemName: "mic.fill")
                                    .font(.system(size: 50))
                                    .foregroundStyle(.white)
                            }
                            
                            Text("Listening...")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundStyle(.red)
                            
                            // Stats
                            HStack(spacing: 40) {
                                VStack {
                                    Text(formatDuration(listenManager.listeningDuration))
                                        .font(.title2)
                                        .fontWeight(.bold)
                                        .monospacedDigit()
                                    Text("Duration")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                
                                VStack {
                                    Text("\(listenManager.currentWordCount)")
                                        .font(.title2)
                                        .fontWeight(.bold)
                                    Text("Words")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                
                                VStack {
                                    Text("\(listenManager.currentItems.count)")
                                        .font(.title2)
                                        .fontWeight(.bold)
                                    Text("Detected")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            
                            // Live transcript preview
                            if !listenManager.currentTranscript.isEmpty {
                                Text(listenManager.currentTranscript.suffix(100))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(3)
                                    .padding(.horizontal, 30)
                            }
                            
                            Button {
                                listenManager.stopListening()
                            } label: {
                                HStack {
                                    Image(systemName: "stop.fill")
                                    Text("Stop Listening")
                                }
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.white)
                                .foregroundStyle(.black)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                            }
                            .padding(.horizontal, 40)
                        }
                    } else {
                        // Ready to listen
                        VStack(spacing: 25) {
                            ZStack {
                                Circle()
                                    .fill(.red.opacity(0.15))
                                    .frame(width: 180, height: 180)
                                
                                Circle()
                                    .fill(.red.opacity(0.25))
                                    .frame(width: 140, height: 140)
                                
                                Image(systemName: "mic.fill")
                                    .font(.system(size: 50))
                                    .foregroundStyle(.red)
                            }
                            
                            Text("Ready to Demo")
                                .font(.title)
                                .fontWeight(.bold)
                            
                            Text("Tap below to start a listening session.\nWe'll show you what we could detect.")
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                            
                            Button {
                                listenManager.startListening()
                            } label: {
                                HStack {
                                    Image(systemName: "mic.fill")
                                    Text("Start Listening")
                                }
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.red)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                            }
                            .padding(.horizontal, 40)
                            
                            // Recent sessions count
                            if !listenManager.sessions.isEmpty {
                                Text("\(listenManager.sessions.count) sessions recorded")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    
                    Spacer()
                    
                    // Privacy note
                    HStack {
                        Image(systemName: "lock.shield.fill")
                            .foregroundStyle(.green)
                        Text("All processing happens on-device. No data leaves your phone.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.bottom, 10)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private var currentItems: [DetectedItem] {
        // This would come from current session
        []
    }
    
    private func formatDuration(_ seconds: TimeInterval) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}

#Preview {
    HomeView()
        .environmentObject(ListenManager())
}
