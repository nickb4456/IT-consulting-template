import SwiftUI

struct ReportView: View {
    @EnvironmentObject var listenManager: ListenManager
    @State private var showAllTime = false
    
    var report: DailyReport {
        showAllTime ? listenManager.getAllTimeReport() : listenManager.getTodayReport()
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Header warning
                        VStack(spacing: 12) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.system(size: 50))
                                .foregroundStyle(.orange)
                            
                            Text("Privacy Wake-Up Call")
                                .font(.title2)
                                .fontWeight(.bold)
                            
                            Text("This is what ANY app with microphone access could learn about you.")
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                        }
                        .padding(.vertical, 20)
                        .frame(maxWidth: .infinity)
                        .background(.orange.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        
                        // Toggle
                        Picker("Time Period", selection: $showAllTime) {
                            Text("Today").tag(false)
                            Text("All Time").tag(true)
                        }
                        .pickerStyle(.segmented)
                        
                        if report.sessions.isEmpty {
                            // No data yet
                            VStack(spacing: 15) {
                                Image(systemName: "waveform.slash")
                                    .font(.system(size: 40))
                                    .foregroundStyle(.secondary)
                                
                                Text("No listening sessions yet")
                                    .font(.headline)
                                
                                Text("Start a demo session to see what could be detected")
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                            }
                            .padding(.vertical, 60)
                        } else {
                            // Stats grid
                            LazyVGrid(columns: [
                                GridItem(.flexible()),
                                GridItem(.flexible())
                            ], spacing: 15) {
                                StatCard(
                                    icon: "clock.fill",
                                    value: formatDuration(report.totalDuration),
                                    label: "Listening Time",
                                    color: .blue
                                )
                                
                                StatCard(
                                    icon: "text.word.spacing",
                                    value: "\(report.totalWords)",
                                    label: "Words Heard",
                                    color: .purple
                                )
                                
                                StatCard(
                                    icon: "tag.fill",
                                    value: "\(report.uniqueTopics)",
                                    label: "Topics Detected",
                                    color: .orange
                                )
                                
                                StatCard(
                                    icon: "number",
                                    value: "\(report.sessions.count)",
                                    label: "Sessions",
                                    color: .green
                                )
                            }
                            
                            // Categories breakdown
                            VStack(alignment: .leading, spacing: 15) {
                                Text("What We Detected")
                                    .font(.headline)
                                
                                ForEach(ItemCategory.allCases, id: \.self) { category in
                                    let items = report.itemsByCategory[category] ?? []
                                    if !items.isEmpty {
                                        CategoryRow(category: category, items: items)
                                    }
                                }
                                
                                if report.allItems.isEmpty {
                                    Text("No specific items detected yet. Keep talking!")
                                        .foregroundStyle(.secondary)
                                        .padding()
                                }
                            }
                            .padding()
                            .background(.white.opacity(0.05))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            
                            // Scary summary
                            VStack(spacing: 15) {
                                Text("⚠️ Think About This")
                                    .font(.headline)
                                    .foregroundStyle(.orange)
                                
                                Text("In just \(formatDuration(report.totalDuration)) of listening, we detected \(report.uniqueTopics) topics. Imagine what apps could learn listening 24/7.")
                                    .multilineTextAlignment(.center)
                                    .foregroundStyle(.secondary)
                                
                                Button {
                                    listenManager.openSettings()
                                } label: {
                                    HStack {
                                        Image(systemName: "gear")
                                        Text("Review Mic Permissions")
                                    }
                                    .fontWeight(.semibold)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(.red)
                                    .foregroundStyle(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                            .padding()
                            .background(.red.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("📊 Your Report")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private func formatDuration(_ seconds: TimeInterval) -> String {
        if seconds < 60 {
            return "\(Int(seconds))s"
        } else if seconds < 3600 {
            return "\(Int(seconds / 60))m \(Int(seconds.truncatingRemainder(dividingBy: 60)))s"
        } else {
            let hours = Int(seconds / 3600)
            let mins = Int((seconds.truncatingRemainder(dividingBy: 3600)) / 60)
            return "\(hours)h \(mins)m"
        }
    }
}

struct StatCard: View {
    let icon: String
    let value: String
    let label: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(color)
            
            Text(value)
                .font(.title)
                .fontWeight(.bold)
            
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(color.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct CategoryRow: View {
    let category: ItemCategory
    let items: [DetectedItem]
    
    @State private var isExpanded = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                withAnimation {
                    isExpanded.toggle()
                }
            } label: {
                HStack {
                    Image(systemName: category.icon)
                        .foregroundStyle(categoryColor)
                    
                    Text(category.rawValue)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Text("\(items.count)")
                        .foregroundStyle(.secondary)
                    
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isExpanded ? 90 : 0))
                }
                .foregroundStyle(.primary)
            }
            
            if isExpanded {
                FlowLayout(spacing: 8) {
                    ForEach(uniqueItems) { item in
                        Text(item.text)
                            .font(.caption)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(categoryColor.opacity(0.2))
                            .clipShape(Capsule())
                    }
                }
            }
        }
        .padding()
        .background(.white.opacity(0.03))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
    
    private var uniqueItems: [DetectedItem] {
        var seen = Set<String>()
        return items.filter { seen.insert($0.text.lowercased()).inserted }
    }
    
    private var categoryColor: Color {
        switch category.color {
        case "orange": return .orange
        case "blue": return .blue
        case "green": return .green
        case "purple": return .purple
        case "pink": return .pink
        case "yellow": return .yellow
        default: return .gray
        }
    }
}

// Simple flow layout for tags
struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = FlowResult(in: proposal.width ?? 0, subviews: subviews, spacing: spacing)
        return result.size
    }
    
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = FlowResult(in: bounds.width, subviews: subviews, spacing: spacing)
        for (index, subview) in subviews.enumerated() {
            subview.place(at: CGPoint(x: bounds.minX + result.positions[index].x,
                                      y: bounds.minY + result.positions[index].y),
                         proposal: .unspecified)
        }
    }
    
    struct FlowResult {
        var size: CGSize = .zero
        var positions: [CGPoint] = []
        
        init(in width: CGFloat, subviews: Subviews, spacing: CGFloat) {
            var x: CGFloat = 0
            var y: CGFloat = 0
            var rowHeight: CGFloat = 0
            
            for subview in subviews {
                let size = subview.sizeThatFits(.unspecified)
                
                if x + size.width > width, x > 0 {
                    x = 0
                    y += rowHeight + spacing
                    rowHeight = 0
                }
                
                positions.append(CGPoint(x: x, y: y))
                rowHeight = max(rowHeight, size.height)
                x += size.width + spacing
            }
            
            self.size = CGSize(width: width, height: y + rowHeight)
        }
    }
}

#Preview {
    ReportView()
        .environmentObject(ListenManager())
}
