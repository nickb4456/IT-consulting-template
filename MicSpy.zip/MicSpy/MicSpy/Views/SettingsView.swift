import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var listenManager: ListenManager
    @State private var showingClearAlert = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                List {
                    // Privacy Section
                    Section {
                        Button {
                            listenManager.openSettings()
                        } label: {
                            HStack {
                                Image(systemName: "mic.fill")
                                    .foregroundStyle(.red)
                                    .frame(width: 30)
                                
                                VStack(alignment: .leading) {
                                    Text("Review Mic Permissions")
                                        .foregroundStyle(.primary)
                                    Text("See which apps have microphone access")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                
                                Spacer()
                                
                                Image(systemName: "arrow.up.right")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    } header: {
                        Text("Privacy")
                    } footer: {
                        Text("Tap to open iOS Settings and review which apps have microphone access.")
                    }
                    
                    // Data Section
                    Section {
                        HStack {
                            Image(systemName: "number")
                                .foregroundStyle(.blue)
                                .frame(width: 30)
                            
                            Text("Total Sessions")
                            
                            Spacer()
                            
                            Text("\(listenManager.sessions.count)")
                                .foregroundStyle(.secondary)
                        }
                        
                        HStack {
                            Image(systemName: "clock")
                                .foregroundStyle(.green)
                                .frame(width: 30)
                            
                            Text("Total Listening Time")
                            
                            Spacer()
                            
                            Text(formatDuration(totalListeningTime))
                                .foregroundStyle(.secondary)
                        }
                        
                        Button(role: .destructive) {
                            showingClearAlert = true
                        } label: {
                            HStack {
                                Image(systemName: "trash")
                                    .frame(width: 30)
                                Text("Clear All Data")
                            }
                        }
                    } header: {
                        Text("Your Data")
                    } footer: {
                        Text("All data is stored locally on your device. Nothing is sent to any server.")
                    }
                    
                    // About Section
                    Section {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("About MicSpy")
                                .font(.headline)
                            
                            Text("This app demonstrates what ANY app with microphone permissions could potentially learn about you.")
                                .foregroundStyle(.secondary)
                            
                            Text("We built this as a privacy awareness tool. All audio processing happens on-device using Apple's Speech framework. No audio or transcripts ever leave your phone.")
                                .foregroundStyle(.secondary)
                            
                            Divider()
                            
                            Text("Think about this:")
                                .fontWeight(.medium)
                                .foregroundStyle(.orange)
                            
                            VStack(alignment: .leading, spacing: 8) {
                                BulletPoint("Social media apps")
                                BulletPoint("Voice assistants")
                                BulletPoint("Games with voice chat")
                                BulletPoint("Video calling apps")
                                BulletPoint("Voice memo apps")
                            }
                            .foregroundStyle(.secondary)
                            
                            Text("All of these have legitimate reasons for mic access, but could also listen when you don't expect it.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 8)
                    }
                    
                    // Tips Section
                    Section {
                        TipRow(
                            icon: "checkmark.shield.fill",
                            color: .green,
                            title: "Review permissions regularly",
                            subtitle: "Settings → Privacy → Microphone"
                        )
                        
                        TipRow(
                            icon: "xmark.circle.fill",
                            color: .red,
                            title: "Revoke unnecessary access",
                            subtitle: "If an app doesn't need your mic, disable it"
                        )
                        
                        TipRow(
                            icon: "eye.fill",
                            color: .orange,
                            title: "Watch for the orange dot",
                            subtitle: "iOS shows an indicator when mic is active"
                        )
                        
                        TipRow(
                            icon: "lock.fill",
                            color: .blue,
                            title: "Use \"Ask Next Time\"",
                            subtitle: "Require apps to ask each time they need mic"
                        )
                    } header: {
                        Text("Privacy Tips")
                    }
                    
                    // Credits
                    Section {
                        HStack {
                            Spacer()
                            VStack(spacing: 4) {
                                Text("MicSpy v1.0")
                                    .font(.caption)
                                Text("Built for Privacy Awareness")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("⚙️ Settings")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Clear All Data?", isPresented: $showingClearAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Clear", role: .destructive) {
                    listenManager.clearAllData()
                }
            } message: {
                Text("This will delete all listening sessions and detected items. This cannot be undone.")
            }
        }
    }
    
    private var totalListeningTime: TimeInterval {
        listenManager.sessions.reduce(0) { $0 + $1.duration }
    }
    
    private func formatDuration(_ seconds: TimeInterval) -> String {
        if seconds < 60 {
            return "\(Int(seconds))s"
        } else if seconds < 3600 {
            return "\(Int(seconds / 60))m"
        } else {
            let hours = Int(seconds / 3600)
            let mins = Int((seconds.truncatingRemainder(dividingBy: 3600)) / 60)
            return "\(hours)h \(mins)m"
        }
    }
}

struct BulletPoint: View {
    let text: String
    
    init(_ text: String) {
        self.text = text
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Text("•")
            Text(text)
        }
    }
}

struct TipRow: View {
    let icon: String
    let color: Color
    let title: String
    let subtitle: String
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 30)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    SettingsView()
        .environmentObject(ListenManager())
}
