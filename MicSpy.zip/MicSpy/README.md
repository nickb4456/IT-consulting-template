# 🎤 MicSpy - Privacy Wake-Up Call

**A privacy awareness app that demonstrates what any app with microphone access could learn about you.**

## Features

- **Demo Listening Sessions** - Start a session to see real-time what's being detected
- **On-Device Processing** - Uses Apple's Speech framework, nothing leaves your phone
- **Daily Reports** - See brands, products, places, and topics detected
- **Privacy Tips** - Learn how to protect yourself
- **One-Tap Permission Review** - Jump directly to iOS mic settings

## Screenshots

```
┌─────────────────────────────────────┐
│  🎤 MicSpy                          │
│                                     │
│        [Pulsing Mic Icon]           │
│                                     │
│  Today's Report:                    │
│  • Brands: Amazon, Netflix, Spotify │
│  • Topics: dinner, work, weekend    │
│  • Products: iPhone, car, coffee    │
│                                     │
│  ⚠️ 23 apps have mic access         │
│  [Review Permissions]               │
│                                     │
└─────────────────────────────────────┘
```

## Setup

1. Open `MicSpy.xcodeproj` in Xcode
2. Set your Development Team in Signing & Capabilities
3. Run on a real iPhone (mic doesn't work in simulator)

## Requirements

- iOS 17.0+
- iPhone only
- Xcode 15+

## Privacy Design

- ✅ All speech recognition is on-device (`requiresOnDeviceRecognition = true`)
- ✅ No audio is stored - only extracted keywords
- ✅ No network calls - data stays on your phone
- ✅ User controls when listening happens
- ✅ Clear data anytime in Settings

## Detection Categories

| Category | Examples |
|----------|----------|
| 🏷️ Brands | Amazon, Netflix, Spotify, Starbucks... |
| 🛒 Products | iPhone, laptop, car, groceries... |
| 🎬 Entertainment | movie, show, podcast, music... |
| 📍 Places | home, work, restaurant, gym... |

## App Store Notes

If publishing to the App Store:
- Category: Utilities
- Keywords: privacy, security, microphone, awareness
- Emphasize educational/awareness purpose
- Make clear it's opt-in demo, not background surveillance

## License

MIT - Use however you want!
