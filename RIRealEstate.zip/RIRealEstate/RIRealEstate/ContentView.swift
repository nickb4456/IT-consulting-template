import SwiftUI

struct ContentView: View {
    @EnvironmentObject var dataManager: DataManager
    
    var body: some View {
        TabView {
            HouseHunterView()
                .tabItem {
                    Label("Homes", systemImage: "house.fill")
                }
            
            LandDealsView()
                .tabItem {
                    Label("Land", systemImage: "map.fill")
                }
            
            SearchView()
                .tabItem {
                    Label("Search", systemImage: "magnifyingglass")
                }
            
            StatsView()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar.fill")
                }
        }
        .accentColor(.purple)
        .overlay {
            if dataManager.isLoading {
                LoadingView()
            }
        }
    }
}

struct LoadingView: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.8)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                ProgressView()
                    .scaleEffect(1.5)
                    .tint(.purple)
                
                Text("Loading RI Properties...")
                    .font(.headline)
                    .foregroundColor(.white)
            }
            .padding(40)
            .background(Color(.systemGray6).opacity(0.95))
            .cornerRadius(20)
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(DataManager())
}
