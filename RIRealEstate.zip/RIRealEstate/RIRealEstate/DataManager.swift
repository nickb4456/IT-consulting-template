import Foundation
import Combine

@MainActor
class DataManager: ObservableObject {
    @Published var properties: [Property] = []
    @Published var isLoading = true
    @Published var error: String?
    
    // Computed property lists
    var homes: [Property] {
        properties.filter { !$0.isLand && $0.beds != nil }
    }
    
    var land: [Property] {
        properties.filter { $0.isLand }
    }
    
    var forSale: [Property] {
        properties.filter { $0.soldDate == nil }
    }
    
    var sold: [Property] {
        properties.filter { $0.soldDate != nil }
    }
    
    var cities: [String] {
        Array(Set(properties.map { $0.city })).sorted()
    }
    
    init() {
        Task {
            await loadData()
        }
    }
    
    func loadData() async {
        isLoading = true
        error = nil
        
        // Try loading from remote URL first
        let url = URL(string: "https://aibridges.org/ri-property-data.json")!
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoder = JSONDecoder()
            properties = try decoder.decode([Property].self, from: data)
            isLoading = false
        } catch {
            self.error = "Failed to load data: \(error.localizedDescription)"
            isLoading = false
            
            // Load sample data for testing
            loadSampleData()
        }
    }
    
    private func loadSampleData() {
        // Sample data for testing when offline
        properties = [
            Property(address: "123 Main St", city: "Providence", price: 450000, beds: 3, baths: 2, sqft: 1800, lotSize: 5000, yearBuilt: 1950, propertyType: "Single Family", dom: 15, soldDate: nil, url: nil, latitude: nil, longitude: nil),
            Property(address: "456 Ocean Ave", city: "Newport", price: 850000, beds: 4, baths: 3, sqft: 2800, lotSize: 8000, yearBuilt: 1920, propertyType: "Single Family", dom: 45, soldDate: nil, url: nil, latitude: nil, longitude: nil),
            Property(address: "789 Park Rd", city: "Warwick", price: 125000, beds: nil, baths: nil, sqft: nil, lotSize: 15000, yearBuilt: nil, propertyType: "Land", dom: 90, soldDate: nil, url: nil, latitude: nil, longitude: nil),
        ]
    }
    
    // MARK: - Analytics
    
    func cityStats() -> [CityStats] {
        let grouped = Dictionary(grouping: properties) { $0.city }
        return grouped.map { city, props in
            let prices = props.map { $0.price }
            let doms = props.compactMap { $0.dom }
            let ppsqfts = props.compactMap { $0.pricePerSqft }
            
            return CityStats(
                city: city,
                count: props.count,
                medianPrice: median(prices),
                avgDOM: doms.isEmpty ? nil : Double(doms.reduce(0, +)) / Double(doms.count),
                pricePerSqft: ppsqfts.isEmpty ? nil : median(ppsqfts)
            )
        }.sorted { $0.medianPrice > $1.medianPrice }
    }
    
    func findDeals(in city: String? = nil, maxPrice: Double? = nil) -> [DealAnalysis] {
        let candidates = homes.filter { home in
            guard home.soldDate == nil else { return false }
            if let city = city, home.city != city { return false }
            if let maxPrice = maxPrice, home.price > maxPrice { return false }
            return true
        }
        
        return candidates.compactMap { home in
            analyzeHomeDeal(home)
        }.sorted { $0.dealScore > $1.dealScore }
    }
    
    func analyzeHomeDeal(_ home: Property) -> DealAnalysis? {
        // Find comps in same city
        let comps = sold.filter {
            $0.city == home.city &&
            !$0.isLand &&
            $0.beds == home.beds &&
            abs(($0.sqft ?? 0) - (home.sqft ?? 0)) < 500
        }
        
        guard comps.count >= 3 else { return nil }
        
        let compPrices = comps.map { $0.price }
        let compPPSqft = comps.compactMap { $0.pricePerSqft }
        
        let medianPrice = median(compPrices)
        let medianPPSqft = median(compPPSqft)
        
        let estimatedValue = medianPPSqft * Double(home.sqft ?? 1500)
        let potentialEquity = estimatedValue - home.price
        
        // Calculate deal score (0-100)
        var score = 50
        if potentialEquity > 50000 { score += 20 }
        else if potentialEquity > 25000 { score += 10 }
        if home.dom ?? 0 > 60 { score += 15 } // Motivated seller
        if home.price < medianPrice * 0.85 { score += 15 }
        
        // Confidence based on comp count
        let confidence = min(100, comps.count * 10 + 40)
        
        return DealAnalysis(
            property: home,
            medianPrice: medianPrice,
            medianPricePerSqft: medianPPSqft,
            estimatedValue: estimatedValue,
            potentialEquity: potentialEquity,
            dealScore: min(100, score),
            confidence: confidence,
            compCount: comps.count
        )
    }
    
    func findLandDeals(buildCostPerSqft: Double = 175) -> [LandDealAnalysis] {
        return land.filter { $0.soldDate == nil }.compactMap { lot in
            analyzeLandDeal(lot, buildCostPerSqft: buildCostPerSqft)
        }.sorted { $0.dealScore > $1.dealScore }
    }
    
    func analyzeLandDeal(_ lot: Property, buildCostPerSqft: Double = 175) -> LandDealAnalysis? {
        // Find median land price in city
        let cityLand = land.filter { $0.city == lot.city }
        guard cityLand.count >= 2 else { return nil }
        
        let medianLandPrice = median(cityLand.map { $0.price })
        
        // Assume 2000 sqft build
        let buildSqft = 2000.0
        let buildCost = buildSqft * buildCostPerSqft * 1.15 // 15% soft costs
        let totalInvestment = lot.price + buildCost
        
        // Find ARV based on similar homes
        let similarHomes = sold.filter {
            $0.city == lot.city &&
            !$0.isLand &&
            ($0.sqft ?? 0) >= 1800 && ($0.sqft ?? 0) <= 2200
        }
        
        guard similarHomes.count >= 2 else { return nil }
        
        let arv = median(similarHomes.map { $0.price })
        let profit = arv - totalInvestment
        
        var score = 50
        if profit > 100000 { score += 25 }
        else if profit > 50000 { score += 15 }
        if lot.dom ?? 0 > 90 { score += 10 }
        if lot.price < medianLandPrice * 0.8 { score += 15 }
        
        return LandDealAnalysis(
            property: lot,
            medianLandPrice: medianLandPrice,
            buildCost: buildCost,
            totalInvestment: totalInvestment,
            estimatedARV: arv,
            potentialProfit: profit,
            dealScore: min(100, score),
            confidence: min(100, similarHomes.count * 8 + 40)
        )
    }
}

// MARK: - Helpers

func median(_ values: [Double]) -> Double {
    guard !values.isEmpty else { return 0 }
    let sorted = values.sorted()
    let mid = sorted.count / 2
    if sorted.count.isMultiple(of: 2) {
        return (sorted[mid - 1] + sorted[mid]) / 2
    }
    return sorted[mid]
}
