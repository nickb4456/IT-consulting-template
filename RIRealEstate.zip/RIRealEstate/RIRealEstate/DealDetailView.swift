import SwiftUI

struct DealDetailView: View {
    let deal: DealAnalysis
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header
                    VStack(spacing: 8) {
                        Text(deal.property.address)
                            .font(.title2.bold())
                        Text(deal.property.city)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.purple.opacity(0.15))
                    .cornerRadius(16)
                    
                    // Key Stats
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 16) {
                        StatCard(title: "Ask Price", value: deal.property.priceFormatted, icon: "tag.fill", color: .pink)
                        StatCard(title: "Est. Value", value: formatPrice(deal.estimatedValue), icon: "house.fill", color: .blue)
                        StatCard(title: "Potential Equity", value: "+\(formatPrice(deal.potentialEquity))", icon: "arrow.up.circle.fill", color: .green)
                        StatCard(title: "Deal Score", value: "\(deal.dealScore)", icon: "star.fill", color: .yellow)
                    }
                    
                    // Property Details
                    GroupBox("Property Details") {
                        VStack(spacing: 12) {
                            DetailRow(label: "Beds", value: deal.property.beds.map { "\($0)" } ?? "—")
                            DetailRow(label: "Baths", value: deal.property.baths.map { "\($0)" } ?? "—")
                            DetailRow(label: "Square Feet", value: deal.property.sqft.map { "\($0.formatted())" } ?? "—")
                            DetailRow(label: "Year Built", value: deal.property.yearBuilt.map { "\($0)" } ?? "—")
                            DetailRow(label: "Days Listed", value: deal.property.dom.map { "\($0)" } ?? "—")
                        }
                    }
                    
                    // Comp Analysis
                    GroupBox("Comp Analysis") {
                        VStack(spacing: 12) {
                            DetailRow(label: "Comps Found", value: "\(deal.compCount)")
                            DetailRow(label: "Median Comp Price", value: formatPrice(deal.medianPrice))
                            DetailRow(label: "Median $/sqft", value: String(format: "$%.0f", deal.medianPricePerSqft))
                            
                            HStack {
                                Text("Confidence")
                                Spacer()
                                ConfidenceBadge(confidence: deal.confidence)
                            }
                        }
                    }
                    
                    // View on Redfin
                    if let urlString = deal.property.url, let url = URL(string: urlString) {
                        Link(destination: url) {
                            Label("View on Redfin", systemImage: "arrow.up.right.square")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple.gradient)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Deal Evaluation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
                
                ToolbarItem(placement: .topBarLeading) {
                    ShareLink(item: "Check out this deal: \(deal.property.address), \(deal.property.city) - \(deal.property.priceFormatted) with \(formatPrice(deal.potentialEquity)) potential equity!") {
                        Image(systemName: "square.and.arrow.up")
                    }
                }
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            Text(value)
                .font(.title3.bold())
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct DetailRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .fontWeight(.medium)
        }
    }
}

#Preview {
    DealDetailView(deal: DealAnalysis(
        property: Property(address: "123 Main St", city: "Providence", price: 350000, beds: 3, baths: 2, sqft: 1800, lotSize: 5000, yearBuilt: 1950, propertyType: "Single Family", dom: 45, soldDate: nil, url: "https://redfin.com", latitude: nil, longitude: nil),
        medianPrice: 425000,
        medianPricePerSqft: 275,
        estimatedValue: 495000,
        potentialEquity: 145000,
        dealScore: 85,
        confidence: 75,
        compCount: 8
    ))
}
