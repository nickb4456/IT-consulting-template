import SwiftUI

struct HouseHunterView: View {
    @EnvironmentObject var dataManager: DataManager
    @State private var selectedCity: String = "All"
    @State private var maxPrice: Double = 1000000
    @State private var selectedDeal: DealAnalysis?
    
    var deals: [DealAnalysis] {
        dataManager.findDeals(
            in: selectedCity == "All" ? nil : selectedCity,
            maxPrice: maxPrice
        )
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filters
                VStack(spacing: 12) {
                    HStack {
                        Text("City")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Picker("City", selection: $selectedCity) {
                            Text("All Cities").tag("All")
                            ForEach(dataManager.cities, id: \.self) { city in
                                Text(city).tag(city)
                            }
                        }
                        .pickerStyle(.menu)
                        .tint(.purple)
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("Max Price")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Spacer()
                            Text(formatPrice(maxPrice))
                                .font(.caption)
                                .foregroundColor(.purple)
                        }
                        Slider(value: $maxPrice, in: 100000...2000000, step: 50000)
                            .tint(.purple)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                
                // Results
                if deals.isEmpty {
                    ContentUnavailableView(
                        "No Deals Found",
                        systemImage: "house.slash",
                        description: Text("Try adjusting your filters")
                    )
                } else {
                    List(deals, id: \.property.id) { deal in
                        DealCard(deal: deal)
                            .onTapGesture {
                                selectedDeal = deal
                            }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("🏠 House Hunter")
            .sheet(item: $selectedDeal) { deal in
                DealDetailView(deal: deal)
            }
        }
    }
}

struct DealCard: View {
    let deal: DealAnalysis
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading) {
                    Text(deal.property.address)
                        .font(.headline)
                    Text(deal.property.city)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
                DealScoreBadge(score: deal.dealScore)
            }
            
            HStack(spacing: 16) {
                StatPill(label: "Ask", value: deal.property.priceFormatted, color: .pink)
                StatPill(label: "Equity", value: "+\(formatPrice(deal.potentialEquity))", color: .green)
                if let beds = deal.property.beds {
                    StatPill(label: "Beds", value: "\(beds)", color: .blue)
                }
            }
            
            HStack {
                ConfidenceBadge(confidence: deal.confidence)
                Spacer()
                Text("\(deal.compCount) comps")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
    }
}

struct DealScoreBadge: View {
    let score: Int
    
    var color: Color {
        if score >= 80 { return .green }
        if score >= 60 { return .yellow }
        return .orange
    }
    
    var body: some View {
        Text("\(score)")
            .font(.title2.bold())
            .foregroundColor(.white)
            .frame(width: 50, height: 50)
            .background(
                Circle()
                    .fill(color.gradient)
            )
    }
}

struct StatPill: View {
    let label: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 2) {
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.caption.bold())
                .foregroundColor(color)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(color.opacity(0.15))
        .cornerRadius(8)
    }
}

struct ConfidenceBadge: View {
    let confidence: Int
    
    var color: Color {
        if confidence >= 70 { return .green }
        if confidence >= 50 { return .yellow }
        return .red
    }
    
    var label: String {
        if confidence >= 70 { return "HIGH" }
        if confidence >= 50 { return "MED" }
        return "LOW"
    }
    
    var body: some View {
        HStack(spacing: 4) {
            Text("\(confidence)%")
                .font(.caption.bold())
            Text(label)
                .font(.caption2)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(color.opacity(0.3))
                .cornerRadius(4)
        }
        .foregroundColor(color)
    }
}

// Extension for Identifiable conformance on DealAnalysis
extension DealAnalysis: Identifiable {
    var id: String { property.id }
}

func formatPrice(_ price: Double) -> String {
    if price >= 1_000_000 {
        return String(format: "$%.1fM", price / 1_000_000)
    } else if price >= 1000 {
        return String(format: "$%.0fK", price / 1_000)
    }
    return String(format: "$%.0f", price)
}

#Preview {
    HouseHunterView()
        .environmentObject(DataManager())
}
