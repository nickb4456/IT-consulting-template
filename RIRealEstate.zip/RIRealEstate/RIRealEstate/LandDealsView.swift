import SwiftUI

struct LandDealsView: View {
    @EnvironmentObject var dataManager: DataManager
    @State private var buildCostPerSqft: Double = 175
    @State private var selectedDeal: LandDealAnalysis?
    
    var deals: [LandDealAnalysis] {
        dataManager.findLandDeals(buildCostPerSqft: buildCostPerSqft)
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Build cost slider
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text("Build Cost per sqft")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("$\(Int(buildCostPerSqft))/sqft")
                            .font(.caption)
                            .foregroundColor(.green)
                    }
                    Slider(value: $buildCostPerSqft, in: 125...300, step: 25)
                        .tint(.green)
                }
                .padding()
                .background(Color(.systemGray6))
                
                if deals.isEmpty {
                    ContentUnavailableView(
                        "No Land Deals",
                        systemImage: "map",
                        description: Text("No profitable land deals found with current settings")
                    )
                } else {
                    List(deals, id: \.property.id) { deal in
                        LandDealCard(deal: deal)
                            .onTapGesture {
                                selectedDeal = deal
                            }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("🏗️ Land Deals")
            .sheet(item: $selectedDeal) { deal in
                LandDealDetailView(deal: deal)
            }
        }
    }
}

struct LandDealCard: View {
    let deal: LandDealAnalysis
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading) {
                    Text(deal.property.address)
                        .font(.headline)
                    Text(deal.property.city)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
                DealScoreBadge(score: deal.dealScore)
            }
            
            HStack(spacing: 12) {
                StatPill(label: "Land", value: deal.property.priceFormatted, color: .orange)
                StatPill(label: "Total", value: formatPrice(deal.totalInvestment), color: .blue)
                StatPill(label: "Profit", value: formatPrice(deal.potentialProfit), color: deal.potentialProfit > 0 ? .green : .red)
            }
            
            if let acres = deal.property.acres {
                HStack {
                    Text(String(format: "%.2f acres", acres))
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Spacer()
                    if let dom = deal.property.dom {
                        Text("\(dom) days listed")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding(.vertical, 8)
    }
}

// Identifiable conformance
extension LandDealAnalysis: Identifiable {
    var id: String { property.id }
}

struct LandDealDetailView: View {
    let deal: LandDealAnalysis
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header
                    VStack(spacing: 8) {
                        Text(deal.property.address)
                            .font(.title2.bold())
                        Text(deal.property.city)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if let acres = deal.property.acres {
                            Text(String(format: "%.2f acres", acres))
                                .font(.caption)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 4)
                                .background(Color.green.opacity(0.2))
                                .cornerRadius(8)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.15))
                    .cornerRadius(16)
                    
                    // Profit Analysis
                    GroupBox("Build-to-Profit Analysis") {
                        VStack(spacing: 16) {
                            ProfitRow(label: "Land Cost", value: deal.property.price, color: .orange)
                            ProfitRow(label: "+ Build Cost", value: deal.buildCost, color: .blue)
                            
                            Divider()
                            
                            ProfitRow(label: "Total Investment", value: deal.totalInvestment, color: .purple, bold: true)
                            ProfitRow(label: "Est. ARV (After Build)", value: deal.estimatedARV, color: .cyan)
                            
                            Divider()
                            
                            HStack {
                                Text("Potential Profit")
                                    .fontWeight(.bold)
                                Spacer()
                                Text(formatPrice(deal.potentialProfit))
                                    .font(.title2.bold())
                                    .foregroundColor(deal.potentialProfit > 0 ? .green : .red)
                            }
                        }
                    }
                    
                    // Deal Score
                    HStack(spacing: 20) {
                        VStack {
                            Text("\(deal.dealScore)")
                                .font(.system(size: 48, weight: .bold))
                                .foregroundColor(.green)
                            Text("Deal Score")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(16)
                        
                        VStack {
                            Text("\(deal.confidence)%")
                                .font(.system(size: 48, weight: .bold))
                                .foregroundColor(.blue)
                            Text("Confidence")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(16)
                    }
                    
                    // View on Redfin
                    if let urlString = deal.property.url, let url = URL(string: urlString) {
                        Link(destination: url) {
                            Label("View on Redfin", systemImage: "arrow.up.right.square")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green.gradient)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Land Evaluation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
}

struct ProfitRow: View {
    let label: String
    let value: Double
    let color: Color
    var bold: Bool = false
    
    var body: some View {
        HStack {
            Text(label)
                .fontWeight(bold ? .bold : .regular)
            Spacer()
            Text(formatPrice(value))
                .foregroundColor(color)
                .fontWeight(bold ? .bold : .medium)
        }
    }
}

#Preview {
    LandDealsView()
        .environmentObject(DataManager())
}
