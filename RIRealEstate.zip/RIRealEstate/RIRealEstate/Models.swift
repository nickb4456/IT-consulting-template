import Foundation

// MARK: - Property Model
struct Property: Codable, Identifiable {
    var id: String { "\(address)-\(city)" }
    
    let address: String
    let city: String
    let price: Double
    let beds: Int?
    let baths: Double?
    let sqft: Int?
    let lotSize: Double?
    let yearBuilt: Int?
    let propertyType: String?
    let dom: Int? // Days on market
    let soldDate: String?
    let url: String?
    let latitude: Double?
    let longitude: Double?
    
    enum CodingKeys: String, CodingKey {
        case address, city, price, beds, baths, sqft
        case lotSize = "lot_size"
        case yearBuilt = "year_built"
        case propertyType = "property_type"
        case dom, soldDate, url, latitude, longitude
    }
    
    var priceFormatted: String {
        if price >= 1_000_000 {
            return String(format: "$%.1fM", price / 1_000_000)
        } else {
            return String(format: "$%.0fK", price / 1_000)
        }
    }
    
    var pricePerSqft: Double? {
        guard let sqft = sqft, sqft > 0 else { return nil }
        return price / Double(sqft)
    }
    
    var acres: Double? {
        guard let lotSize = lotSize else { return nil }
        return lotSize / 43560
    }
    
    var isLand: Bool {
        propertyType?.lowercased().contains("land") == true ||
        propertyType?.lowercased().contains("vacant") == true ||
        (beds == nil && sqft == nil)
    }
}

// MARK: - Deal Analysis
struct DealAnalysis {
    let property: Property
    let medianPrice: Double
    let medianPricePerSqft: Double
    let estimatedValue: Double
    let potentialEquity: Double
    let dealScore: Int
    let confidence: Int
    let compCount: Int
    
    var confidenceLabel: String {
        if confidence >= 70 { return "HIGH" }
        if confidence >= 50 { return "MEDIUM" }
        return "LOW"
    }
    
    var confidenceColor: String {
        if confidence >= 70 { return "green" }
        if confidence >= 50 { return "yellow" }
        return "red"
    }
}

// MARK: - Land Deal Analysis
struct LandDealAnalysis {
    let property: Property
    let medianLandPrice: Double
    let buildCost: Double
    let totalInvestment: Double
    let estimatedARV: Double // After Repair Value
    let potentialProfit: Double
    let dealScore: Int
    let confidence: Int
}

// MARK: - City Stats
struct CityStats: Identifiable {
    var id: String { city }
    let city: String
    let count: Int
    let medianPrice: Double
    let avgDOM: Double?
    let pricePerSqft: Double?
}
