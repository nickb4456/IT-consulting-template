import SwiftUI

struct SearchView: View {
    @EnvironmentObject var dataManager: DataManager
    @State private var searchText = ""
    @State private var selectedCity = "All"
    @State private var propertyType = "All"
    @State private var minPrice: Double = 0
    @State private var maxPrice: Double = 2000000
    @State private var minBeds = 0
    
    var filteredProperties: [Property] {
        dataManager.properties.filter { property in
            // Search text
            if !searchText.isEmpty {
                let searchLower = searchText.lowercased()
                guard property.address.lowercased().contains(searchLower) ||
                      property.city.lowercased().contains(searchLower) else {
                    return false
                }
            }
            
            // City filter
            if selectedCity != "All" && property.city != selectedCity {
                return false
            }
            
            // Property type
            if propertyType == "Homes" && property.isLand { return false }
            if propertyType == "Land" && !property.isLand { return false }
            
            // Price range
            if property.price < minPrice || property.price > maxPrice {
                return false
            }
            
            // Beds
            if minBeds > 0 && (property.beds ?? 0) < minBeds {
                return false
            }
            
            return true
        }
        .sorted { $0.price < $1.price }
        .prefix(100)
        .map { $0 }
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Search bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                    TextField("Search address or city...", text: $searchText)
                        .textFieldStyle(.plain)
                    
                    if !searchText.isEmpty {
                        Button {
                            searchText = ""
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .padding()
                
                // Filters
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        FilterChip(title: "City", value: selectedCity) {
                            Menu {
                                Button("All Cities") { selectedCity = "All" }
                                ForEach(dataManager.cities, id: \.self) { city in
                                    Button(city) { selectedCity = city }
                                }
                            } label: {
                                EmptyView()
                            }
                        }
                        
                        FilterChip(title: "Type", value: propertyType) {
                            Menu {
                                Button("All") { propertyType = "All" }
                                Button("Homes") { propertyType = "Homes" }
                                Button("Land") { propertyType = "Land" }
                            } label: {
                                EmptyView()
                            }
                        }
                        
                        FilterChip(title: "Beds", value: minBeds == 0 ? "Any" : "\(minBeds)+") {
                            Menu {
                                Button("Any") { minBeds = 0 }
                                ForEach(1...5, id: \.self) { beds in
                                    Button("\(beds)+ beds") { minBeds = beds }
                                }
                            } label: {
                                EmptyView()
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.bottom, 8)
                
                // Results count
                HStack {
                    Text("\(filteredProperties.count) properties")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.bottom, 4)
                
                // Results list
                List(filteredProperties) { property in
                    NavigationLink(destination: PropertyDetailView(property: property)) {
                        PropertyRow(property: property)
                    }
                }
                .listStyle(.plain)
            }
            .navigationTitle("🔍 Search")
        }
    }
}

struct FilterChip: View {
    let title: String
    let value: String
    @ViewBuilder let menu: () -> some View
    
    var body: some View {
        Menu {
            menu()
        } label: {
            HStack(spacing: 4) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(value)
                    .font(.caption.bold())
                Image(systemName: "chevron.down")
                    .font(.caption2)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(.systemGray5))
            .cornerRadius(20)
        }
    }
}

struct PropertyRow: View {
    let property: Property
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(property.address)
                    .font(.headline)
                Spacer()
                Text(property.priceFormatted)
                    .font(.headline)
                    .foregroundColor(.purple)
            }
            
            HStack {
                Text(property.city)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if let beds = property.beds {
                    Label("\(beds)", systemImage: "bed.double.fill")
                        .font(.caption)
                }
                if let baths = property.baths {
                    Label("\(Int(baths))", systemImage: "shower.fill")
                        .font(.caption)
                }
                if let sqft = property.sqft {
                    Label("\(sqft)", systemImage: "square.fill")
                        .font(.caption)
                }
            }
            .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}

struct PropertyDetailView: View {
    let property: Property
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header
                VStack(spacing: 8) {
                    Text(property.address)
                        .font(.title2.bold())
                    Text(property.city)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(property.priceFormatted)
                        .font(.title.bold())
                        .foregroundColor(.purple)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.purple.opacity(0.15))
                .cornerRadius(16)
                
                // Details
                GroupBox("Property Details") {
                    VStack(spacing: 12) {
                        if let beds = property.beds {
                            DetailRow(label: "Bedrooms", value: "\(beds)")
                        }
                        if let baths = property.baths {
                            DetailRow(label: "Bathrooms", value: "\(baths)")
                        }
                        if let sqft = property.sqft {
                            DetailRow(label: "Square Feet", value: sqft.formatted())
                        }
                        if let yearBuilt = property.yearBuilt {
                            DetailRow(label: "Year Built", value: "\(yearBuilt)")
                        }
                        if let type = property.propertyType {
                            DetailRow(label: "Type", value: type)
                        }
                        if let dom = property.dom {
                            DetailRow(label: "Days Listed", value: "\(dom)")
                        }
                        if let ppsqft = property.pricePerSqft {
                            DetailRow(label: "$/sqft", value: String(format: "$%.0f", ppsqft))
                        }
                    }
                }
                
                // Redfin link
                if let urlString = property.url, let url = URL(string: urlString) {
                    Link(destination: url) {
                        Label("View on Redfin", systemImage: "arrow.up.right.square")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple.gradient)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Property")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    SearchView()
        .environmentObject(DataManager())
}
