import SwiftUI
import Charts

struct StatsView: View {
    @EnvironmentObject var dataManager: DataManager
    
    var stats: (total: Int, forSale: Int, sold: Int, medianPrice: Double, cities: Int) {
        let props = dataManager.properties
        return (
            total: props.count,
            forSale: dataManager.forSale.count,
            sold: dataManager.sold.count,
            medianPrice: median(props.map { $0.price }),
            cities: dataManager.cities.count
        )
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Summary Stats
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 12) {
                        MiniStatCard(value: "\(stats.total)", label: "Properties", icon: "house.fill", color: .purple)
                        MiniStatCard(value: "\(stats.forSale)", label: "For Sale", icon: "tag.fill", color: .green)
                        MiniStatCard(value: "\(stats.sold)", label: "Sold", icon: "checkmark.circle.fill", color: .blue)
                    }
                    
                    // Median price
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Median Price")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(formatPrice(stats.medianPrice))
                                .font(.title.bold())
                                .foregroundColor(.pink)
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            Text("Cities Covered")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text("\(stats.cities)")
                                .font(.title.bold())
                                .foregroundColor(.cyan)
                        }
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(16)
                    
                    // Price by City Chart
                    GroupBox("Median Price by City") {
                        CityPriceChart(cityStats: dataManager.cityStats().prefix(10).map { $0 })
                            .frame(height: 250)
                    }
                    
                    // Property Type Breakdown
                    GroupBox("Property Types") {
                        PropertyTypeChart(homes: dataManager.homes.count, land: dataManager.land.count)
                            .frame(height: 200)
                    }
                    
                    // Top Cities Table
                    GroupBox("Top Cities by Price") {
                        VStack(spacing: 0) {
                            ForEach(dataManager.cityStats().prefix(10)) { stat in
                                HStack {
                                    Text(stat.city)
                                        .font(.subheadline)
                                    Spacer()
                                    Text("\(stat.count)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .frame(width: 40)
                                    Text(formatPrice(stat.medianPrice))
                                        .font(.subheadline.bold())
                                        .foregroundColor(.purple)
                                        .frame(width: 80, alignment: .trailing)
                                }
                                .padding(.vertical, 8)
                                Divider()
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("📈 Market Stats")
        }
    }
}

struct MiniStatCard: View {
    let value: String
    let label: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(color)
            Text(value)
                .font(.title3.bold())
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct CityPriceChart: View {
    let cityStats: [CityStats]
    
    var body: some View {
        Chart(cityStats) { stat in
            BarMark(
                x: .value("Price", stat.medianPrice),
                y: .value("City", stat.city)
            )
            .foregroundStyle(
                LinearGradient(
                    colors: [.purple, .pink],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(4)
        }
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 4)) { value in
                AxisGridLine()
                AxisValueLabel {
                    if let price = value.as(Double.self) {
                        Text(formatPrice(price))
                            .font(.caption2)
                    }
                }
            }
        }
    }
}

struct PropertyTypeChart: View {
    let homes: Int
    let land: Int
    
    var data: [(String, Int, Color)] {
        [
            ("Homes", homes, .purple),
            ("Land", land, .green)
        ]
    }
    
    var body: some View {
        Chart(data, id: \.0) { item in
            SectorMark(
                angle: .value("Count", item.1),
                innerRadius: .ratio(0.5),
                angularInset: 2
            )
            .foregroundStyle(item.2)
            .annotation(position: .overlay) {
                VStack {
                    Text(item.0)
                        .font(.caption.bold())
                    Text("\(item.1)")
                        .font(.caption2)
                }
                .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    StatsView()
        .environmentObject(DataManager())
}
