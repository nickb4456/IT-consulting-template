# Legal Toolbar - Word Add-in

A professional legal document toolkit for Microsoft Word that streamlines contract drafting and document review.

## Features

### 📜 Legal Clause Library
- **Pre-built clauses** across 5 categories: Contracts, Liability, IP, Confidentiality, Termination
- **One-click insertion** of professionally drafted boilerplate language
- **Searchable library** with category filtering
- Clauses include:
  - Entire Agreement, Amendment, Assignment, Governing Law
  - Limitation of Liability, Indemnification, Disclaimers
  - IP Ownership, License Grants, IP Warranties
  - NDA clauses, Confidentiality Exceptions
  - Term, Termination for Cause/Convenience, Survival

### 🔍 Defined Terms Highlighter
- **Auto-detect** defined terms in quotes (e.g., "Agreement" means...)
- **Highlight** all instances of defined terms throughout document
- **List** all defined terms for quick reference
- Visual legend showing defined vs. potentially undefined terms

### 🔗 Cross-Reference Checker
- **Scan** document for section references (Section 1.2, Section 5.3, etc.)
- **Validate** that referenced sections actually exist
- **Identify** broken or invalid cross-references
- **List** all document sections for easy navigation

### 📝 Redline Tools
- Quick access to track changes summary
- Accept/Reject all changes helpers
- Integration with Word's built-in revision features

### ✍️ Signature Block Inserter
- **5 signature formats**:
  - Single Party
  - Two Parties (side-by-side)
  - Corporate (with attestation)
  - With Witness
  - With Notary (full acknowledgment)
- Properly formatted with signature lines and fields

## Installation

### Sideloading for Development

1. Clone this repository
2. Start a local HTTPS server:
   ```bash
   npx http-server -S -C localhost.pem -K localhost-key.pem -p 3000
   ```
3. In Word, go to **Insert → My Add-ins → Upload My Add-in**
4. Select `manifest.xml`

### Production Deployment

1. Update URLs in `manifest.xml` to your production server
2. Deploy files to your web server with HTTPS
3. Submit to Office Store or deploy via Microsoft 365 Admin Center

## Project Structure

```
legal-toolbar/
├── manifest.xml          # Office Add-in manifest
├── src/
│   ├── taskpane.html    # Main UI
│   └── taskpane.js      # Add-in logic
├── assets/              # Icons (16x16, 32x32, 80x80)
└── README.md
```

## Requirements

- Microsoft Word 2016 or later (Windows/Mac)
- Microsoft 365 (Web)
- Office.js API 1.1+

## API Requirements

| Feature | API Set |
|---------|---------|
| Insert clauses | Word 1.1 |
| Search & highlight | Word 1.1 |
| Font formatting | Word 1.1 |
| Paragraph manipulation | Word 1.1 |

## Development

```bash
# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build
```

## Customization

### Adding Custom Clauses

Edit `taskpane.js` and add clauses to the `clauseLibrary` object:

```javascript
clauseLibrary.contracts.push({
    id: 'my-clause',
    title: 'My Custom Clause',
    desc: 'Description for UI',
    text: 'Full clause text...'
});
```

### Custom Signature Blocks

Add new formats to the `signatureBlocks` object in `taskpane.js`.

## License

MIT License

## Support

For issues or feature requests, please open a GitHub issue.
