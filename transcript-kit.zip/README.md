# YouTube Transcript Kit

Run this on your Mac (residential IP bypasses YouTube blocks).

## Setup
```bash
npm install
```

## Usage
1. Edit `local-transcript-scraper.js` and add video IDs to VIDEO_IDS array
   OR copy `youtube-trends-data.json` to this folder

2. Run:
```bash
npm run scrape
```

3. Upload `transcripts.json` to server:
```bash
scp transcripts.json ubuntu@your-server:~/.openclaw/workspace/youtube-trends-colony/data/
```

## Notes
- Rate limited to 1 request/second
- Works with videos that have captions enabled
- Outputs JSON with full transcript text
