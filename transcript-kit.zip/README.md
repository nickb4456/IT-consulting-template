# 🎬 YouTube Transcript Scraper

Extracts subtitles/captions from YouTube videos.
Run this on your Mac — residential IPs aren't blocked by YouTube.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Add video IDs to video-ids.txt (one per line)
#    Get IDs from YouTube URLs: youtube.com/watch?v=VIDEO_ID_HERE

# 3. Run the scraper
npm run scrape

# 4. Upload results to your server
scp transcripts.json ubuntu@YOUR-SERVER:~/path/to/data/
```

## Input: video-ids.txt

```
# Comments start with #
dQw4w9WgXcQ
jNQXAC9IVRw
abc123xyz
```

## Output: transcripts.json

```json
{
  "scrapedAt": "2026-02-14T...",
  "total": 3,
  "success": 2,
  "failed": 1,
  "transcripts": [
    {
      "videoId": "dQw4w9WgXcQ",
      "success": true,
      "text": "We're no strangers to love...",
      "segments": 42
    },
    {
      "videoId": "xyz123",
      "success": false,
      "error": "Transcript not available"
    }
  ]
}
```

## Tips

- **Get video IDs from URLs:** `youtube.com/watch?v=THIS_PART`
- **Rate limit:** 1.5 sec between requests (be nice to YouTube)
- **Not all videos have transcripts** — auto-captions need to be enabled
- **Works best with English videos** — change `lang: 'en'` in script for others

## Troubleshooting

**"Transcript not available"**
- Video doesn't have captions enabled
- Video is age-restricted or private
- Try a different video

**"Too many requests"**  
- Increase DELAY_MS in the script
- Wait a few minutes and retry
