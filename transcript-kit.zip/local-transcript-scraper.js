#!/usr/bin/env node
/**
 * Local Transcript Scraper
 * Run this on your local machine (residential IP) to extract YouTube transcripts
 * 
 * Usage:
 *   npm install youtube-transcript axios
 *   node local-transcript-scraper.js
 *   # Then upload transcripts.json to server
 */

const { YoutubeTranscript } = require('youtube-transcript');
const fs = require('fs');
const path = require('path');

// Load video IDs from trends data or provide manually
const VIDEO_IDS = [
    // Add video IDs here, or load from a file
    // "dQw4w9WgXcQ",
    // "jNQXAC9IVRw"
];

// Or load from file
const TRENDS_DATA_PATH = process.env.TRENDS_DATA || 'youtube-trends-data.json';

async function loadVideoIds() {
    if (VIDEO_IDS.length > 0) return VIDEO_IDS;
    
    try {
        const data = JSON.parse(fs.readFileSync(TRENDS_DATA_PATH, 'utf8'));
        const ids = [];
        for (const niche of Object.values(data.niches || {})) {
            for (const video of niche.videos || []) {
                if (video.videoId) ids.push(video.videoId);
            }
        }
        console.log(`Loaded ${ids.length} video IDs from ${TRENDS_DATA_PATH}`);
        return ids;
    } catch (e) {
        console.error('Could not load trends data:', e.message);
        return VIDEO_IDS;
    }
}

async function getTranscript(videoId) {
    try {
        const transcript = await YoutubeTranscript.fetchTranscript(videoId, { lang: 'en' });
        const fullText = transcript.map(t => t.text).join(' ');
        return {
            videoId,
            success: true,
            language: 'en',
            segmentCount: transcript.length,
            charCount: fullText.length,
            text: fullText,
            segments: transcript.slice(0, 10) // First 10 segments as sample
        };
    } catch (e) {
        return {
            videoId,
            success: false,
            error: e.message
        };
    }
}

async function main() {
    const videoIds = await loadVideoIds();
    
    if (videoIds.length === 0) {
        console.log('No video IDs to process. Add IDs to VIDEO_IDS array or provide TRENDS_DATA path.');
        return;
    }
    
    console.log(`Processing ${videoIds.length} videos...`);
    
    const results = [];
    let success = 0, failed = 0;
    
    for (let i = 0; i < videoIds.length; i++) {
        const videoId = videoIds[i];
        process.stdout.write(`[${i+1}/${videoIds.length}] ${videoId}... `);
        
        const result = await getTranscript(videoId);
        results.push(result);
        
        if (result.success) {
            success++;
            console.log(`✓ ${result.charCount} chars`);
        } else {
            failed++;
            console.log(`✗ ${result.error}`);
        }
        
        // Rate limit: 1 request per second
        await new Promise(r => setTimeout(r, 1000));
    }
    
    // Save results
    const output = {
        scrapedAt: new Date().toISOString(),
        totalVideos: videoIds.length,
        success,
        failed,
        transcripts: results
    };
    
    const outputPath = 'transcripts.json';
    fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));
    console.log(`\nSaved ${success} transcripts to ${outputPath}`);
    console.log(`Upload this file to your server for analysis.`);
}

main().catch(console.error);
