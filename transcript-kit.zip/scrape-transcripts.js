#!/usr/bin/env node
/**
 * YouTube Transcript Scraper
 * Run on your Mac (residential IP bypasses YouTube's server blocks)
 */

const { YoutubeTranscript } = require('youtube-transcript');
const fs = require('fs');

// === CONFIGURATION ===
const INPUT_FILE = 'video-ids.txt';      // One video ID per line
const OUTPUT_FILE = 'transcripts.json';
const DELAY_MS = 1500;                    // Be nice to YouTube

async function getTranscript(videoId) {
    try {
        const transcript = await YoutubeTranscript.fetchTranscript(videoId, { lang: 'en' });
        const text = transcript.map(t => t.text).join(' ');
        return { videoId, success: true, text, segments: transcript.length };
    } catch (e) {
        return { videoId, success: false, error: e.message };
    }
}

async function main() {
    // Load video IDs
    if (!fs.existsSync(INPUT_FILE)) {
        console.log(`Create ${INPUT_FILE} with one video ID per line, e.g.:`);
        console.log('dQw4w9WgXcQ');
        console.log('jNQXAC9IVRw');
        process.exit(1);
    }
    
    const ids = fs.readFileSync(INPUT_FILE, 'utf8')
        .split('\n')
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('#'));
    
    console.log(`\n🎬 Scraping ${ids.length} videos...\n`);
    
    const results = [];
    let success = 0, failed = 0;
    
    for (let i = 0; i < ids.length; i++) {
        const id = ids[i];
        process.stdout.write(`[${i+1}/${ids.length}] ${id}... `);
        
        const result = await getTranscript(id);
        results.push(result);
        
        if (result.success) {
            success++;
            console.log(`✅ ${result.text.length} chars`);
        } else {
            failed++;
            console.log(`❌ ${result.error.slice(0, 50)}`);
        }
        
        if (i < ids.length - 1) await new Promise(r => setTimeout(r, DELAY_MS));
    }
    
    // Save results
    const output = {
        scrapedAt: new Date().toISOString(),
        total: ids.length,
        success,
        failed,
        transcripts: results
    };
    
    fs.writeFileSync(OUTPUT_FILE, JSON.stringify(output, null, 2));
    console.log(`\n✨ Done! ${success} transcripts saved to ${OUTPUT_FILE}`);
    console.log(`📤 Upload to server: scp ${OUTPUT_FILE} ubuntu@YOUR-SERVER:~/.openclaw/workspace/youtube-trends-colony/data/`);
}

main().catch(console.error);
